# analyze_results.py
# Aggregates and visualizes evaluation outputs in results.jsonl.
# - Produces thesis-friendly plots with large fonts.
# - Compares TAS vs baselines (semantic similarity, DST-style set accuracy, judge rubric).
# - Plots TAS components (CO/WCS/CP only) and recovery diagnostics (RR/RD) separately.
#
# NOTE: This script is additive-only w.r.t. schemas. It reads existing results.jsonl
# and generates figures + CSV summaries. It never mutates logs/results.jsonl.

import json
import os
import shutil
from collections import Counter
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from config import RESULTS_FILE, FIG_DIR

# -----------------------------
# Thesis-friendly plot defaults
# -----------------------------
plt.rcParams.update({
    "font.size": 18,
    "axes.titlesize": 24,
    "axes.labelsize": 22,
    "xtick.labelsize": 18,
    "ytick.labelsize": 18,
    "legend.fontsize": 16,
})

SUB_DIRS = [
    "bar_charts",
    "distributions",
    "radars",
    "correlations",
    "over_time",
    "tables",
    "stacked_bars",
    "scatter",
    "three_d",
]

def _prepare_dirs(base_dir: str, sub_dirs: List[str]) -> Dict[str, str]:
    """Always clears previous visualization outputs for a fresh run."""
    if os.path.exists(base_dir):
        shutil.rmtree(base_dir)
    os.makedirs(base_dir, exist_ok=True)
    out = {}
    for s in sub_dirs:
        p = os.path.join(base_dir, s)
        os.makedirs(p, exist_ok=True)
        out[s] = p
    print(f"--- Cleared and prepared figure directories in '{base_dir}' ---")
    return out

DIRS = _prepare_dirs(FIG_DIR, SUB_DIRS)

def _load_results(path: str) -> pd.DataFrame:
    with open(path, "r", encoding="utf-8") as f:
        records = [json.loads(line) for line in f if line.strip()]
    df = pd.DataFrame(records)
    if df.empty:
        raise RuntimeError(f"No records found in {path}")
    # Flatten judge dict if present
    if "judge" in df.columns:
        judge_df = pd.json_normalize(df["judge"]).add_prefix("judge.")
        df = pd.concat([df.drop(columns=["judge"]), judge_df], axis=1)
    # Ensure detail is dict
    if "detail" in df.columns:
        df["detail"] = df["detail"].apply(lambda x: x if isinstance(x, dict) else {})
    else:
        df["detail"] = [{} for _ in range(len(df))]
    return df

df = _load_results(RESULTS_FILE)

MODEL_COL = "model_name" if "model_name" in df.columns else ("model" if "model" in df.columns else None)
if MODEL_COL is None:
    raise RuntimeError("Could not find a model identifier column (expected 'model_name' or 'model').")

# -----------------------------
# Canonical metric accessors
# -----------------------------
def _col(df_: pd.DataFrame, preferred: str, fallbacks: List[str]) -> str:
    if preferred in df_.columns:
        return preferred
    for fb in fallbacks:
        if fb in df_.columns:
            return fb
    # create a zero column (safe additive) for plotting
    df_[preferred] = 0.0
    return preferred

TAS = _col(df, "trajectory_adaptation_score_mean", ["context_adaptation_score_mean", "context_adaptation_score", "adaptation_score_mean", "adaptation_score"])
CO  = _col(df, "concept_overlap_mean", ["cross_coherence_mean", "cross_coherence"])
WCS = _col(df, "weighted_constraint_similarity_mean", ["constraint_similarity_mean", "context_retention_mean", "context_retention"])
CP  = _col(df, "copying_penalty_mean", ["copy_penalty_mean", "topic_interference_mean", "topic_interference"])

RR  = _col(df, "topic_recovery_rate", ["recovery_rate"])
RD  = _col(df, "avg_recovery_delay", ["avg_delay"])

RR_COS = _col(df, "recovery_rate_cosine", [])
RD_COS = _col(df, "avg_recovery_delay_cosine", [])

SEM = _col(df, "semantic_similarity_mean", [])
DST_F1 = _col(df, "dst_f1_mean", [])
SAT = _col(df, "recommendation_satisfaction_mean", [])

# Judge metrics (1..5 typically)
judge_cols = [c for c in df.columns if c.startswith("judge.rubric_")]
if not judge_cols:
    # compatibility: older keys without prefix
    judge_cols = [c for c in df.columns if c.startswith("rubric_")]

# -----------------------------
# Summary tables
# -----------------------------
num_cols = df.select_dtypes(include=[np.number]).columns.tolist()
df_summary = df.groupby(MODEL_COL)[num_cols].mean().reset_index()

summary_csv = os.path.join(DIRS["tables"], "model_metrics.csv")
df_summary.to_csv(summary_csv, index=False)
print(f"Saved: {summary_csv}")

# Recovery table
df_recovery = df_summary[[MODEL_COL, RR, RD, RR_COS, RD_COS]].copy()
df_recovery.to_csv(os.path.join(DIRS["tables"], "recovery_metrics.csv"), index=False)

# -----------------------------
# Helper plotting functions
# -----------------------------
def _legend_outside():
    plt.legend(loc="center left", bbox_to_anchor=(1.02, 0.5), frameon=False)

def _save(figpath: str):
    plt.tight_layout()
    plt.savefig(figpath, dpi=220, bbox_inches="tight")
    plt.close()
    print(f"Saved plot: {figpath}")

# -----------------------------
# 1) Bar chart: TAS vs baselines
# -----------------------------
base_metrics = [TAS, SEM, DST_F1, SAT]
labels = {
    TAS: "TAS",
    SEM: "Semantic Similarity",
    DST_F1: "DST F1 (set overlap)",
    SAT: "Rec. Satisfaction",
}
plot_df = df_summary[[MODEL_COL] + base_metrics].copy()

x = np.arange(len(plot_df[MODEL_COL]))
width = 0.18
plt.figure(figsize=(16, 7))
for j, mcol in enumerate(base_metrics):
    plt.bar(x + (j - 1.5) * width, plot_df[mcol].values, width, label=labels[mcol])
plt.xticks(x, plot_df[MODEL_COL], rotation=30, ha="right")
plt.ylim(0, 1.05)
plt.ylabel("Score (0–1)")
plt.title("Proposed TAS vs Baselines (mean across conversations)")
_legend_outside()
_save(os.path.join(DIRS["bar_charts"], "tas_vs_baselines.png"))

# -----------------------------
# 2) Bar chart: TAS components only
# -----------------------------
comp_df = df_summary[[MODEL_COL, CO, WCS, CP]].copy()
# CP is a penalty; invert for comparability (higher is better)
comp_df["1-CP"] = 1.0 - comp_df[CP].astype(float)

plt.figure(figsize=(16, 7))
metrics2 = [CO, WCS, "1-CP"]
width = 0.22
for j, mcol in enumerate(metrics2):
    plt.bar(x + (j - 1) * width, comp_df[mcol].values, width, label=mcol)
plt.xticks(x, comp_df[MODEL_COL], rotation=30, ha="right")
plt.ylim(0, 1.05)
plt.ylabel("Component score (0–1)")
plt.title("TAS Components by Model")
_legend_outside()
_save(os.path.join(DIRS["bar_charts"], "tas_components_bar.png"))

# -----------------------------
# 3) TAS components radar (NO CAS)
# -----------------------------
labels_r = ["CO", "WCS", "1-CP"]
angles = np.linspace(0, 2*np.pi, len(labels_r), endpoint=False).tolist()
angles += angles[:1]

fig = plt.figure(figsize=(10, 10))
ax = fig.add_subplot(111, polar=True)
for _, row in comp_df.iterrows():
    vals = [float(row[CO]), float(row[WCS]), float(row["1-CP"])]
    vals = [float(np.clip(v, 0.0, 1.0)) for v in vals]
    vals += vals[:1]
    ax.plot(angles, vals, linewidth=2, label=row[MODEL_COL])
    ax.fill(angles, vals, alpha=0.08)
ax.set_thetagrids(np.degrees(angles[:-1]), labels_r)
ax.set_title("TAS Components Radar (higher is better)", pad=25)
ax.legend(loc="center left", bbox_to_anchor=(1.15, 0.5), frameon=False)
plt.tight_layout()
plt.savefig(os.path.join(DIRS["radars"], "tas_components_radar.png"), dpi=220, bbox_inches="tight")
plt.close()

# -----------------------------
# 4) Recovery RR/RD plots
# -----------------------------
plt.figure(figsize=(16, 6))
plt.bar(x - width/2, df_recovery[RR].values, width, label="RR (Jaccard)")
plt.bar(x + width/2, df_recovery[RR_COS].values, width, label="RR (Cosine)")
plt.xticks(x, df_recovery[MODEL_COL], rotation=30, ha="right")
plt.ylim(0, 1.05)
plt.ylabel("Recovery Rate")
plt.title("Shift Recovery Rate")
_legend_outside()
_save(os.path.join(DIRS["bar_charts"], "recovery_rate.png"))

plt.figure(figsize=(16, 6))
plt.bar(x - width/2, df_recovery[RD].fillna(0).values, width, label="RD (Jaccard)")
plt.bar(x + width/2, df_recovery[RD_COS].fillna(0).values, width, label="RD (Cosine)")
plt.xticks(x, df_recovery[MODEL_COL], rotation=30, ha="right")
plt.ylabel("Avg Recovery Delay (turns)")
plt.title("Shift Recovery Delay")
_legend_outside()
_save(os.path.join(DIRS["bar_charts"], "recovery_delay.png"))

# -----------------------------
# 5) Judge stacked normalized (0–1)
# -----------------------------
if judge_cols:
    jdf = df_summary[[MODEL_COL] + judge_cols].copy()
    # normalize [1,5] -> [0,1]
    for c in judge_cols:
        jdf[c] = (jdf[c].astype(float) - 1.0) / 4.0

    plt.figure(figsize=(16, 7))
    bottom = np.zeros(len(jdf))
    for c in judge_cols:
        plt.bar(x, jdf[c].values, bottom=bottom, label=c.split(".")[-1].replace("_", " ").title())
        bottom += jdf[c].values
    plt.xticks(x, jdf[MODEL_COL], rotation=30, ha="right")
    plt.ylabel("Normalized judge score (stacked)")
    plt.title("LLM-as-a-Judge Rubric (Normalized 0–1)")
    _legend_outside()
    _save(os.path.join(DIRS["stacked_bars"], "judge_stacked_normalized.png"))

# -----------------------------
# 6) Distributions (TAS + baselines)
# -----------------------------
for mcol, name in [(TAS, "TAS"), (SEM, "Semantic Similarity"), (DST_F1, "DST F1"), (SAT, "Rec. Satisfaction")]:
    plt.figure(figsize=(12, 6))
    for model in df[MODEL_COL].unique():
        vals = df[df[MODEL_COL] == model][mcol].dropna().astype(float).values
        if len(vals) == 0:
            continue
        plt.hist(vals, bins=20, alpha=0.35, label=model)
    plt.title(f"Distribution: {name}")
    plt.xlabel("Score")
    plt.ylabel("Count")
    _legend_outside()
    _save(os.path.join(DIRS["distributions"], f"dist_{mcol}.png"))

# -----------------------------
# 7) Correlations (TAS vs baselines, TAS vs judge)
# -----------------------------
corr_cols = [TAS, SEM, DST_F1, SAT]
if judge_cols:
    corr_cols += judge_cols
corr_df = df[corr_cols].copy().astype(float)
corr = corr_df.corr(method="spearman")
corr.to_csv(os.path.join(DIRS["tables"], "spearman_correlation.csv"))

plt.figure(figsize=(12, 10))
plt.imshow(corr.values, aspect="auto")
plt.xticks(range(len(corr.columns)), [c.replace("judge.", "") for c in corr.columns], rotation=90)
plt.yticks(range(len(corr.index)), [c.replace("judge.", "") for c in corr.index])
plt.colorbar()
plt.title("Spearman correlation (TAS / baselines / judge)")
_save(os.path.join(DIRS["correlations"], "spearman_heatmap.png"))

# Scatter: TAS vs each baseline
for mcol, name in [(SEM, "Semantic Similarity"), (DST_F1, "DST F1"), (SAT, "Rec. Satisfaction")]:
    plt.figure(figsize=(10, 8))
    for model in df[MODEL_COL].unique():
        sub = df[df[MODEL_COL] == model]
        plt.scatter(sub[mcol].astype(float), sub[TAS].astype(float), alpha=0.6, label=model)
    plt.xlabel(name)
    plt.ylabel("TAS")
    plt.title(f"TAS vs {name}")
    _legend_outside()
    _save(os.path.join(DIRS["scatter"], f"scatter_tas_vs_{mcol}.png"))

# -----------------------------
# 8) Over-time: TAS per turn (mean across conversations)
# -----------------------------
def _extract_turn_series(detail: dict, key: str) -> List[float]:
    # grounded logs use detail.turn_scores.{tas, cc, cr, i}
    ts = detail.get("turn_scores") or {}
    series = ts.get(key)
    if isinstance(series, list):
        return [float(x) for x in series]
    return []

series_by_model: Dict[str, List[List[float]]] = {}
for _, row in df.iterrows():
    series = _extract_turn_series(row["detail"], "tas")
    if not series:
        continue
    series_by_model.setdefault(row[MODEL_COL], []).append(series)

if series_by_model:
    max_len = max(len(s) for arr in series_by_model.values() for s in arr)
    plt.figure(figsize=(16, 7))
    for model, arr in series_by_model.items():
        mat = np.full((len(arr), max_len), np.nan, dtype=float)
        for i, s in enumerate(arr):
            mat[i, :len(s)] = s
        mean = np.nanmean(mat, axis=0)
        plt.plot(np.arange(1, max_len + 1), mean, linewidth=3, label=model)
    plt.xlabel("Turn index")
    plt.ylabel("TAS (mean)")
    plt.title("TAS over Turns (mean across conversations)")
    _legend_outside()
    _save(os.path.join(DIRS["over_time"], "tas_over_turns.png"))

# -----------------------------
# 9) Conversation deviation / volatility (remedy 'nothing shown')
# -----------------------------
# Volatility = stddev of per-turn TAS within a conversation; then mean per model.
vol_rows = []
for _, row in df.iterrows():
    series = _extract_turn_series(row["detail"], "tas")
    if series:
        vol_rows.append({MODEL_COL: row[MODEL_COL], "tas_volatility": float(np.std(series))})
if vol_rows:
    vol_df = pd.DataFrame(vol_rows)
    vol_summary = vol_df.groupby(MODEL_COL)["tas_volatility"].mean().reset_index()
    vol_summary.to_csv(os.path.join(DIRS["tables"], "tas_volatility.csv"), index=False)

    plt.figure(figsize=(16, 6))
    plt.bar(np.arange(len(vol_summary)), vol_summary["tas_volatility"].values)
    plt.xticks(np.arange(len(vol_summary)), vol_summary[MODEL_COL], rotation=30, ha="right")
    plt.ylabel("Stddev(TAS per turn)")
    plt.title("Average Conversation Deviation (TAS volatility)")
    _save(os.path.join(DIRS["bar_charts"], "tas_volatility.png"))

# -----------------------------
# 10) 3D visualization (turn × component × value)
# -----------------------------
try:
    from mpl_toolkits.mplot3d import Axes3D  # noqa: F401
    for model in df[MODEL_COL].unique():
        sub = df[df[MODEL_COL] == model]
        if sub.empty:
            continue
        detail = sub.iloc[0]["detail"]
        ts = detail.get("turn_scores") or {}
        tas = ts.get("tas") or []
        cc = ts.get("cc") or []
        cr = ts.get("cr") or []
        i = ts.get("i") or []
        if not tas:
            continue
        # Build points
        turns = np.arange(1, len(tas)+1)
        comps = [("CO", cc), ("WCS", cr), ("CP", [1.0 - float(x) for x in i]), ("TAS", tas)]
        fig = plt.figure(figsize=(12, 9))
        ax = fig.add_subplot(111, projection='3d')
        for ci, (name, arr) in enumerate(comps):
            z = np.array(arr, dtype=float)
            y = np.full_like(turns, ci, dtype=float)
            ax.scatter(turns, y, z, label=name, s=25)
        ax.set_xlabel("Turn")
        ax.set_ylabel("Component")
        ax.set_yticks(range(len(comps)))
        ax.set_yticklabels([c[0] for c in comps])
        ax.set_zlabel("Score")
        ax.set_title(f"3D: TAS components over turns ({model})")
        ax.legend(loc="center left", bbox_to_anchor=(1.05, 0.5), frameon=False)
        plt.tight_layout()
        plt.savefig(os.path.join(DIRS["three_d"], f"3d_tas_components_{model}.png"), dpi=220, bbox_inches="tight")
        plt.close()
except Exception:
    pass

print("--- Analysis complete. ---")
