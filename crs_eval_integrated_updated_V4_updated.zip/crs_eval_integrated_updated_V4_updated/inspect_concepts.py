#!/usr/bin/env python3
"""inspect_concepts.py

Utility to inspect extracted concepts to confirm they are not dominated by useless/common tokens.

Reads results.jsonl and aggregates:
- Top system concepts overall and by model
- Top plot keywords (plot=...) to spot contamination
- Coverage of structured vs plot concepts

Outputs CSVs under figures/concept_inspection/.
"""

import json
import os
from collections import Counter, defaultdict

import pandas as pd

from config import RESULTS_FILE, FIG_DIR

OUT_DIR = os.path.join(FIG_DIR, "concept_inspection")

def main():
    if not os.path.exists(RESULTS_FILE):
        raise SystemExit(f"Missing {RESULTS_FILE}. Run evaluations first.")
    os.makedirs(OUT_DIR, exist_ok=True)

    overall = Counter()
    by_model = defaultdict(Counter)
    plot_overall = Counter()

    with open(RESULTS_FILE, "r", encoding="utf-8") as f:
        for line in f:
            if not line.strip():
                continue
            rec = json.loads(line)
            model = rec.get("model_name") or rec.get("model") or "unknown"
            detail = rec.get("detail") or {}
            turns = detail.get("turn_concepts") or []
            for t in turns:
                for c in t.get("system_concepts", []):
                    overall[c] += 1
                    by_model[model][c] += 1
                    if c.startswith("plot=") or c.startswith("plot_kw="):
                        plot_overall[c] += 1

    pd.DataFrame(overall.most_common(200), columns=["concept", "count"]).to_csv(
        os.path.join(OUT_DIR, "top_system_concepts_overall.csv"), index=False
    )
    pd.DataFrame(plot_overall.most_common(200), columns=["plot_concept", "count"]).to_csv(
        os.path.join(OUT_DIR, "top_plot_concepts_overall.csv"), index=False
    )

    # per-model
    rows = []
    for model, c in by_model.items():
        for concept, cnt in c.most_common(50):
            rows.append({"model": model, "concept": concept, "count": cnt})
    pd.DataFrame(rows).to_csv(os.path.join(OUT_DIR, "top_system_concepts_by_model.csv"), index=False)

    print(f"Wrote concept inspection CSVs to: {OUT_DIR}")

if __name__ == "__main__":
    main()
